

 #include "main.h"

#define FONT_WIDTH 4
#define FONT_HEIGHT 6

void DrawString(const char* str, uint8_t x, uint8_t y);
void drawdot(char x,char y,char vis);


